export type TemplateId = 'classic' | 'modern' | 'minimal'
export type FontStyle = 'serif' | 'sans'

export type Personal = {
  fullName: string
  title: string
  email: string
  phone: string
  location: string
  website: string
  linkedin: string
  summary: string
}

export type Experience = {
  id: string
  role: string
  company: string
  location: string
  start: string
  end: string
  current: boolean
  description: string
}

export type Education = {
  id: string
  degree: string
  school: string
  location: string
  start: string
  end: string
  details: string
}

export type Skill = { id: string; name: string }
export type Language = { id: string; name: string; level: string }

export type Design = {
  template: TemplateId
  accent: string
  font: FontStyle
}

export type CV = {
  personal: Personal
  experience: Experience[]
  education: Education[]
  skills: Skill[]
  languages: Language[]
  design: Design
}

export type ListKey = 'experience' | 'education' | 'skills' | 'languages'
export type ListItem<K extends ListKey> = CV[K][number]

export const ACCENTS = [
  { name: 'Ink', value: '#1f2937' },
  { name: 'Forest', value: '#1f5f4a' },
  { name: 'Navy', value: '#1e3a8a' },
  { name: 'Burgundy', value: '#7f1d1d' },
  { name: 'Ochre', value: '#8a5a12' },
] as const

export const TEMPLATES: { id: TemplateId; name: string; description: string }[] = [
  { id: 'classic', name: 'Classic', description: 'Centered, timeless' },
  { id: 'modern', name: 'Modern', description: 'Colored sidebar' },
  { id: 'minimal', name: 'Minimal', description: 'Clean timeline' },
]

export function emptyItem<K extends ListKey>(key: K, id: string): ListItem<K> {
  const items: { [P in ListKey]: ListItem<P> } = {
    experience: { id, role: '', company: '', location: '', start: '', end: '', current: false, description: '' },
    education: { id, degree: '', school: '', location: '', start: '', end: '', details: '' },
    skills: { id, name: '' },
    languages: { id, name: '', level: '' },
  }
  return items[key] as ListItem<K>
}

export const EMPTY_CV: CV = {
  personal: {
    fullName: '',
    title: '',
    email: '',
    phone: '',
    location: '',
    website: '',
    linkedin: '',
    summary: '',
  },
  experience: [],
  education: [],
  skills: [],
  languages: [],
  design: { template: 'classic', accent: ACCENTS[1].value, font: 'serif' },
}

export const SAMPLE_CV: CV = {
  personal: {
    fullName: 'Amara Okafor',
    title: 'Senior Product Designer',
    email: 'amara.okafor@email.com',
    phone: '+44 20 7946 0958',
    location: 'London, UK',
    website: 'amaraokafor.design',
    linkedin: 'linkedin.com/in/amaraokafor',
    summary:
      'Product designer with 8 years of experience shaping digital products used by millions. I pair rigorous research with crisp visual craft, and I care deeply about accessible, inclusive design that holds up at scale.',
  },
  experience: [
    {
      id: 'exp-1',
      role: 'Senior Product Designer',
      company: 'Northwind Bank',
      location: 'London',
      start: 'Mar 2021',
      end: '',
      current: true,
      description:
        'Led the redesign of the mobile banking app, lifting weekly active users by 23%\nBuilt and maintained a cross-platform design system adopted by 9 product teams\nMentored four junior designers through structured critique and pairing',
    },
    {
      id: 'exp-2',
      role: 'Product Designer',
      company: 'Fieldnote',
      location: 'Remote',
      start: 'Jun 2018',
      end: 'Feb 2021',
      current: false,
      description:
        'Designed onboarding flows that cut time-to-value from 6 days to 2\nRan 40+ usability sessions and turned findings into a prioritized roadmap',
    },
  ],
  education: [
    {
      id: 'edu-1',
      degree: 'BA (Hons) Graphic Communication',
      school: 'University of the Arts London',
      location: 'London',
      start: '2013',
      end: '2016',
      details: 'First-Class Honours. Dissertation on wayfinding in public transit systems.',
    },
  ],
  skills: [
    { id: 'sk-1', name: 'Interaction design' },
    { id: 'sk-2', name: 'Design systems' },
    { id: 'sk-3', name: 'User research' },
    { id: 'sk-4', name: 'Prototyping' },
    { id: 'sk-5', name: 'Figma' },
    { id: 'sk-6', name: 'Accessibility (WCAG)' },
  ],
  languages: [
    { id: 'lang-1', name: 'English', level: 'Native' },
    { id: 'lang-2', name: 'French', level: 'Professional' },
  ],
  design: { template: 'classic', accent: ACCENTS[1].value, font: 'serif' },
}

export function parseCV(raw: unknown): CV | null {
  if (!raw || typeof raw !== 'object') return null
  const data = raw as Partial<CV>
  if (!data.personal || typeof data.personal !== 'object') return null
  const asArray = <T,>(value: unknown): T[] => (Array.isArray(value) ? (value as T[]) : [])
  return {
    personal: { ...EMPTY_CV.personal, ...data.personal },
    experience: asArray<Experience>(data.experience),
    education: asArray<Education>(data.education),
    skills: asArray<Skill>(data.skills),
    languages: asArray<Language>(data.languages),
    design: { ...EMPTY_CV.design, ...(data.design ?? {}) },
  }
}

export function bulletLines(text: string) {
  return text
    .split('\n')
    .map((line) => line.replace(/^[-•*]\s*/, '').trim())
    .filter(Boolean)
}

export function dateRange(start: string, end: string, current?: boolean) {
  const finish = current ? 'Present' : end
  if (start && finish) return `${start} – ${finish}`
  return start || finish
}
