'use client'

import { useState } from 'react'
import { Eye, PencilLine } from 'lucide-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'
import { AppHeader } from './app-header'
import { CvPreview } from './cv-preview'
import { CvProvider } from './cv-provider'
import { DesignSection } from './editor/design-section'
import { EducationSection } from './editor/education-section'
import { ExperienceSection } from './editor/experience-section'
import { PersonalSection } from './editor/personal-section'
import { LanguagesSection, SkillsSection } from './editor/skills-section'

type MobileView = 'edit' | 'preview'

export function CvBuilder() {
  const [mobileView, setMobileView] = useState<MobileView>('edit')

  return (
    <CvProvider>
      <div className="flex h-dvh flex-col bg-background print:block print:h-auto">
        <AppHeader />

        <div className="grid min-h-0 flex-1 lg:grid-cols-[minmax(440px,540px)_1fr] print:block">
          <aside
            aria-label="CV editor"
            className={cn(
              'min-h-0 overflow-y-auto border-r bg-background print:hidden',
              mobileView === 'preview' && 'hidden lg:block',
            )}
          >
            <Tabs defaultValue="content" className="gap-0">
              <div className="sticky top-0 z-10 border-b bg-background/90 px-4 py-3 backdrop-blur sm:px-6">
                <TabsList className="w-full">
                  <TabsTrigger value="content">Content</TabsTrigger>
                  <TabsTrigger value="design">Design</TabsTrigger>
                </TabsList>
              </div>
              <TabsContent value="content" className="grid gap-4 px-4 py-5 pb-24 sm:px-6 lg:pb-8">
                <PersonalSection />
                <ExperienceSection />
                <EducationSection />
                <SkillsSection />
                <LanguagesSection />
              </TabsContent>
              <TabsContent value="design" className="px-4 py-5 pb-24 sm:px-6 lg:pb-8">
                <DesignSection />
              </TabsContent>
            </Tabs>
          </aside>

          <main
            aria-label="CV preview"
            className={cn(
              'min-h-0 overflow-y-auto bg-muted px-4 py-6 pb-24 sm:px-10 sm:py-10 lg:pb-10 print:block print:overflow-visible print:bg-white print:p-0',
              mobileView === 'edit' && 'hidden lg:block',
            )}
          >
            <CvPreview />
          </main>
        </div>

        <nav
          aria-label="Switch view"
          className="fixed inset-x-0 bottom-0 z-20 flex justify-center p-4 lg:hidden print:hidden"
        >
          <div className="flex rounded-full border bg-card p-1 shadow-lg">
            {(
              [
                { id: 'edit', label: 'Edit', icon: PencilLine },
                { id: 'preview', label: 'Preview', icon: Eye },
              ] as const
            ).map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                type="button"
                aria-pressed={mobileView === id}
                onClick={() => setMobileView(id)}
                className={cn(
                  'flex items-center gap-2 rounded-full px-5 py-2 text-sm font-medium transition-colors focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none',
                  mobileView === id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                <Icon className="size-4" aria-hidden="true" />
                {label}
              </button>
            ))}
          </div>
        </nav>
      </div>
    </CvProvider>
  )
}
