import { Globe, Link2, Mail, MapPin, Phone } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import type { Personal } from '@/lib/cv-types'
import { bulletLines } from '@/lib/cv-types'

export const PAGE_WIDTH = 794
export const PAGE_HEIGHT = 1123

export type ContactItem = { key: string; icon: LucideIcon; value: string }

export function contactItems(p: Personal): ContactItem[] {
  return [
    { key: 'email', icon: Mail, value: p.email },
    { key: 'phone', icon: Phone, value: p.phone },
    { key: 'location', icon: MapPin, value: p.location },
    { key: 'website', icon: Globe, value: p.website },
    { key: 'linkedin', icon: Link2, value: p.linkedin },
  ].filter((item) => item.value.trim())
}

export function Bullets({ text, className }: { text: string; className?: string }) {
  const lines = bulletLines(text)
  if (lines.length === 0) return null
  return (
    <ul className={className ?? 'mt-1.5 list-disc space-y-1 pl-4 marker:text-neutral-400'}>
      {lines.map((line, index) => (
        <li key={index}>{line}</li>
      ))}
    </ul>
  )
}
