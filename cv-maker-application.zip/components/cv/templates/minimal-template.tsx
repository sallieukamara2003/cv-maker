import type { CV } from '@/lib/cv-types'
import { dateRange } from '@/lib/cv-types'
import { Bullets, contactItems } from './shared'

function Row({ label, children }: { label: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[130px_1fr] gap-6 break-inside-avoid">
      <div className="pt-0.5 text-[11.5px] text-neutral-500">{label}</div>
      <div>{children}</div>
    </div>
  )
}

function Section({ title, accent, children }: { title: string; accent: string; children: React.ReactNode }) {
  return (
    <section className="mt-9">
      <h2 className="mb-4 text-[12px] font-semibold tracking-[0.15em] uppercase" style={{ color: accent }}>
        {title}
      </h2>
      <div className="space-y-5">{children}</div>
    </section>
  )
}

export function MinimalTemplate({ cv }: { cv: CV }) {
  const { personal: p, design } = cv
  const accent = design.accent
  const contacts = contactItems(p)

  return (
    <div className="px-16 py-16 text-[12.5px] leading-relaxed text-neutral-700">
      <header className="border-b border-neutral-200 pb-8">
        <h1 className="text-[40px] leading-none font-light tracking-tight text-neutral-900">
          {p.fullName || 'Your Name'}
        </h1>
        {p.title ? (
          <p className="mt-3 text-[14px] font-medium" style={{ color: accent }}>
            {p.title}
          </p>
        ) : null}
        {contacts.length > 0 ? (
          <ul className="mt-5 flex flex-wrap gap-x-5 gap-y-1 text-[11.5px] text-neutral-600">
            {contacts.map(({ key, value }) => (
              <li key={key}>{value}</li>
            ))}
          </ul>
        ) : null}
      </header>

      {p.summary ? (
        <section className="mt-8">
          <p className="max-w-[560px] text-[13.5px] leading-relaxed text-neutral-800">{p.summary}</p>
        </section>
      ) : null}

      {cv.experience.length > 0 ? (
        <Section title="Experience" accent={accent}>
          {cv.experience.map((job) => (
            <Row key={job.id} label={dateRange(job.start, job.end, job.current)}>
              <h3 className="text-[13.5px] font-semibold text-neutral-900">
                {job.role || 'Role'}
                {job.company ? <span className="font-normal text-neutral-500">{`, ${job.company}`}</span> : null}
              </h3>
              {job.location ? <p className="text-[11.5px] text-neutral-500">{job.location}</p> : null}
              <Bullets text={job.description} />
            </Row>
          ))}
        </Section>
      ) : null}

      {cv.education.length > 0 ? (
        <Section title="Education" accent={accent}>
          {cv.education.map((edu) => (
            <Row key={edu.id} label={dateRange(edu.start, edu.end)}>
              <h3 className="text-[13.5px] font-semibold text-neutral-900">{edu.degree || 'Degree'}</h3>
              <p className="text-neutral-500">{[edu.school, edu.location].filter(Boolean).join(', ')}</p>
              {edu.details ? <p className="mt-1">{edu.details}</p> : null}
            </Row>
          ))}
        </Section>
      ) : null}

      {cv.skills.length > 0 ? (
        <Section title="Skills" accent={accent}>
          <Row label="Core">
            <p>{cv.skills.map((s) => s.name).join(', ')}</p>
          </Row>
        </Section>
      ) : null}

      {cv.languages.length > 0 ? (
        <Section title="Languages" accent={accent}>
          {cv.languages.map((l) => (
            <Row key={l.id} label={l.level || '—'}>
              <p className="font-medium text-neutral-900">{l.name}</p>
            </Row>
          ))}
        </Section>
      ) : null}
    </div>
  )
}
