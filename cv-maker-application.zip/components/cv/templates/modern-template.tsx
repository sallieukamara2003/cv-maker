import type { CV } from '@/lib/cv-types'
import { dateRange } from '@/lib/cv-types'
import { Bullets, contactItems } from './shared'

function SideHeading({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="mb-2.5 border-b border-white/25 pb-1.5 text-[10.5px] font-semibold tracking-[0.2em] text-white/70 uppercase">
      {children}
    </h2>
  )
}

function MainHeading({ children, accent }: { children: React.ReactNode; accent: string }) {
  return (
    <h2 className="mb-3 text-[12px] font-bold tracking-[0.18em] uppercase" style={{ color: accent }}>
      {children}
    </h2>
  )
}

export function ModernTemplate({ cv }: { cv: CV }) {
  const { personal: p, design } = cv
  const accent = design.accent
  const contacts = contactItems(p)
  const initials = (p.fullName || 'Your Name')
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('')

  return (
    <div className="flex min-h-[inherit] text-[12.5px] leading-relaxed text-neutral-700">
      <aside className="w-[34%] shrink-0 px-8 py-12 text-white" style={{ backgroundColor: accent }}>
        <div
          className="flex size-20 items-center justify-center rounded-full border-2 border-white/40 text-[26px] font-semibold"
          aria-hidden="true"
        >
          {initials}
        </div>
        <h1 className="mt-6 text-[26px] leading-tight font-semibold">{p.fullName || 'Your Name'}</h1>
        {p.title ? <p className="mt-1 text-[13px] text-white/80">{p.title}</p> : null}

        {contacts.length > 0 ? (
          <section className="mt-9">
            <SideHeading>Contact</SideHeading>
            <ul className="space-y-2 text-[11.5px]">
              {contacts.map(({ key, icon: Icon, value }) => (
                <li key={key} className="flex items-start gap-2 break-all">
                  <Icon className="mt-0.5 size-3.5 shrink-0 text-white/70" aria-hidden="true" />
                  {value}
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        {cv.skills.length > 0 ? (
          <section className="mt-8">
            <SideHeading>Skills</SideHeading>
            <ul className="flex flex-wrap gap-1.5 text-[11px]">
              {cv.skills.map((s) => (
                <li key={s.id} className="rounded bg-white/15 px-2 py-0.5">
                  {s.name}
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        {cv.languages.length > 0 ? (
          <section className="mt-8">
            <SideHeading>Languages</SideHeading>
            <ul className="space-y-1.5 text-[11.5px]">
              {cv.languages.map((l) => (
                <li key={l.id} className="flex justify-between gap-2">
                  <span>{l.name}</span>
                  <span className="text-white/65">{l.level}</span>
                </li>
              ))}
            </ul>
          </section>
        ) : null}
      </aside>

      <div className="flex-1 px-10 py-12">
        {p.summary ? (
          <section>
            <MainHeading accent={accent}>About me</MainHeading>
            <p>{p.summary}</p>
          </section>
        ) : null}

        {cv.experience.length > 0 ? (
          <section className="mt-9">
            <MainHeading accent={accent}>Experience</MainHeading>
            <div className="space-y-5 border-l-2 border-neutral-200 pl-5">
              {cv.experience.map((job) => (
                <article key={job.id} className="relative break-inside-avoid">
                  <span
                    className="absolute top-1.5 -left-[26px] size-2.5 rounded-full border-2 border-white"
                    style={{ backgroundColor: accent }}
                    aria-hidden="true"
                  />
                  <p className="text-[11px] font-medium tracking-wide text-neutral-500 uppercase">
                    {dateRange(job.start, job.end, job.current)}
                  </p>
                  <h3 className="text-[14px] font-semibold text-neutral-900">{job.role || 'Role'}</h3>
                  <p className="text-[12px] text-neutral-600">
                    {[job.company, job.location].filter(Boolean).join(' · ')}
                  </p>
                  <Bullets text={job.description} />
                </article>
              ))}
            </div>
          </section>
        ) : null}

        {cv.education.length > 0 ? (
          <section className="mt-9">
            <MainHeading accent={accent}>Education</MainHeading>
            <div className="space-y-4">
              {cv.education.map((edu) => (
                <article key={edu.id} className="break-inside-avoid">
                  <p className="text-[11px] font-medium tracking-wide text-neutral-500 uppercase">
                    {dateRange(edu.start, edu.end)}
                  </p>
                  <h3 className="text-[14px] font-semibold text-neutral-900">{edu.degree || 'Degree'}</h3>
                  <p className="text-[12px] text-neutral-600">
                    {[edu.school, edu.location].filter(Boolean).join(' · ')}
                  </p>
                  {edu.details ? <p className="mt-1">{edu.details}</p> : null}
                </article>
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </div>
  )
}
