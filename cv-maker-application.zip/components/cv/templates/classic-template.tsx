import type { CV } from '@/lib/cv-types'
import { dateRange } from '@/lib/cv-types'
import { Bullets, contactItems } from './shared'

function Heading({ children, accent }: { children: React.ReactNode; accent: string }) {
  return (
    <h2 className="mb-3 flex items-center gap-3 text-[11px] font-semibold tracking-[0.2em] uppercase" style={{ color: accent }}>
      {children}
      <span className="h-px flex-1 bg-neutral-200" aria-hidden="true" />
    </h2>
  )
}

export function ClassicTemplate({ cv }: { cv: CV }) {
  const { personal: p, design } = cv
  const accent = design.accent
  const contacts = contactItems(p)

  return (
    <div className="px-16 py-14 text-[13px] leading-relaxed text-neutral-700">
      <header className="text-center">
        <h1 className="text-[34px] leading-tight font-semibold tracking-tight text-neutral-900">
          {p.fullName || 'Your Name'}
        </h1>
        {p.title ? (
          <p className="mt-1 text-[15px]" style={{ color: accent }}>
            {p.title}
          </p>
        ) : null}
        {contacts.length > 0 ? (
          <ul className="mt-4 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-[12px] text-neutral-600">
            {contacts.map(({ key, icon: Icon, value }) => (
              <li key={key} className="flex items-center gap-1.5">
                <Icon className="size-3" style={{ color: accent }} aria-hidden="true" />
                {value}
              </li>
            ))}
          </ul>
        ) : null}
      </header>

      {p.summary ? (
        <section className="mt-9">
          <Heading accent={accent}>Profile</Heading>
          <p>{p.summary}</p>
        </section>
      ) : null}

      {cv.experience.length > 0 ? (
        <section className="mt-8">
          <Heading accent={accent}>Experience</Heading>
          <div className="space-y-5">
            {cv.experience.map((job) => (
              <article key={job.id} className="break-inside-avoid">
                <div className="flex items-baseline justify-between gap-4">
                  <h3 className="text-[14px] font-semibold text-neutral-900">{job.role || 'Role'}</h3>
                  <p className="shrink-0 text-[12px] text-neutral-500">{dateRange(job.start, job.end, job.current)}</p>
                </div>
                <p className="text-[12.5px] italic text-neutral-600">
                  {[job.company, job.location].filter(Boolean).join(' · ')}
                </p>
                <Bullets text={job.description} />
              </article>
            ))}
          </div>
        </section>
      ) : null}

      {cv.education.length > 0 ? (
        <section className="mt-8">
          <Heading accent={accent}>Education</Heading>
          <div className="space-y-4">
            {cv.education.map((edu) => (
              <article key={edu.id} className="break-inside-avoid">
                <div className="flex items-baseline justify-between gap-4">
                  <h3 className="text-[14px] font-semibold text-neutral-900">{edu.degree || 'Degree'}</h3>
                  <p className="shrink-0 text-[12px] text-neutral-500">{dateRange(edu.start, edu.end)}</p>
                </div>
                <p className="text-[12.5px] italic text-neutral-600">
                  {[edu.school, edu.location].filter(Boolean).join(' · ')}
                </p>
                {edu.details ? <p className="mt-1">{edu.details}</p> : null}
              </article>
            ))}
          </div>
        </section>
      ) : null}

      {cv.skills.length > 0 || cv.languages.length > 0 ? (
        <div className="mt-8 grid grid-cols-2 gap-10">
          {cv.skills.length > 0 ? (
            <section className={cv.languages.length === 0 ? 'col-span-2' : undefined}>
              <Heading accent={accent}>Skills</Heading>
              <p>{cv.skills.map((s) => s.name).join(' · ')}</p>
            </section>
          ) : null}
          {cv.languages.length > 0 ? (
            <section className={cv.skills.length === 0 ? 'col-span-2' : undefined}>
              <Heading accent={accent}>Languages</Heading>
              <ul className="space-y-0.5">
                {cv.languages.map((l) => (
                  <li key={l.id}>
                    <span className="font-medium text-neutral-900">{l.name}</span>
                    {l.level ? <span className="text-neutral-500">{` — ${l.level}`}</span> : null}
                  </li>
                ))}
              </ul>
            </section>
          ) : null}
        </div>
      ) : null}
    </div>
  )
}
