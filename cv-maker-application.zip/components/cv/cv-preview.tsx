'use client'

import { useEffect, useRef, useState } from 'react'
import { useCv } from '@/components/cv/cv-provider'
import { cn } from '@/lib/utils'
import { ClassicTemplate } from './templates/classic-template'
import { MinimalTemplate } from './templates/minimal-template'
import { ModernTemplate } from './templates/modern-template'
import { PAGE_HEIGHT, PAGE_WIDTH } from './templates/shared'

const TEMPLATE_COMPONENTS = {
  classic: ClassicTemplate,
  modern: ModernTemplate,
  minimal: MinimalTemplate,
}

export function CvPreview() {
  const { cv } = useCv()
  const containerRef = useRef<HTMLDivElement>(null)
  const pageRef = useRef<HTMLDivElement>(null)
  const [scale, setScale] = useState(0.7)
  const [pageHeight, setPageHeight] = useState(PAGE_HEIGHT)

  useEffect(() => {
    const container = containerRef.current
    const page = pageRef.current
    if (!container || !page) return
    const observer = new ResizeObserver(() => {
      const available = container.clientWidth
      setScale(Math.min(1, available / PAGE_WIDTH))
      setPageHeight(page.offsetHeight)
    })
    observer.observe(container)
    observer.observe(page)
    return () => observer.disconnect()
  }, [])

  const Template = TEMPLATE_COMPONENTS[cv.design.template]

  return (
    <div ref={containerRef} className="mx-auto w-full max-w-[794px] print:max-w-none">
      <div
        className="relative print:h-auto!"
        style={{ height: pageHeight * scale }}
      >
        <div
          ref={pageRef}
          id="cv-document"
          className={cn(
            'absolute top-0 left-0 origin-top-left overflow-hidden bg-white shadow-[0_1px_2px_rgba(0,0,0,0.06),0_12px_40px_-12px_rgba(0,0,0,0.25)] print:static print:transform-none! print:overflow-visible print:shadow-none',
            cv.design.font === 'serif' ? 'font-serif' : 'font-sans',
          )}
          style={{ width: PAGE_WIDTH, minHeight: PAGE_HEIGHT, transform: `scale(${scale})` }}
        >
          <Template cv={cv} />
        </div>
      </div>
    </div>
  )
}
