'use client'

import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import {
  type CV,
  type Design,
  type ListItem,
  type ListKey,
  type Personal,
  SAMPLE_CV,
  emptyItem,
} from '@/lib/cv-types'

type CvContextValue = {
  cv: CV
  updatePersonal: (field: keyof Personal, value: string) => void
  updateItem: <K extends ListKey>(key: K, id: string, patch: Partial<ListItem<K>>) => void
  addItem: <K extends ListKey>(key: K, initial?: Partial<ListItem<K>>) => void
  removeItem: (key: ListKey, id: string) => void
  moveItem: (key: ListKey, id: string, direction: -1 | 1) => void
  updateDesign: (patch: Partial<Design>) => void
  replaceCv: (cv: CV) => void
}

const CvContext = createContext<CvContextValue | null>(null)

export function CvProvider({ children }: { children: React.ReactNode }) {
  const [cv, setCv] = useState<CV>(SAMPLE_CV)

  const updatePersonal = useCallback((field: keyof Personal, value: string) => {
    setCv((prev) => ({ ...prev, personal: { ...prev.personal, [field]: value } }))
  }, [])

  const updateItem = useCallback(
    <K extends ListKey>(key: K, id: string, patch: Partial<ListItem<K>>) => {
      setCv((prev) => ({
        ...prev,
        [key]: (prev[key] as ListItem<K>[]).map((item) => (item.id === id ? { ...item, ...patch } : item)),
      }))
    },
    [],
  )

  const addItem = useCallback(<K extends ListKey>(key: K, initial?: Partial<ListItem<K>>) => {
    const item = { ...emptyItem(key, crypto.randomUUID()), ...initial }
    setCv((prev) => ({ ...prev, [key]: [...prev[key], item] }))
  }, [])

  const removeItem = useCallback((key: ListKey, id: string) => {
    setCv((prev) => ({
      ...prev,
      [key]: (prev[key] as { id: string }[]).filter((item) => item.id !== id),
    }))
  }, [])

  const moveItem = useCallback((key: ListKey, id: string, direction: -1 | 1) => {
    setCv((prev) => {
      const list = [...(prev[key] as { id: string }[])]
      const index = list.findIndex((item) => item.id === id)
      const target = index + direction
      if (index < 0 || target < 0 || target >= list.length) return prev
      ;[list[index], list[target]] = [list[target], list[index]]
      return { ...prev, [key]: list }
    })
  }, [])

  const updateDesign = useCallback((patch: Partial<Design>) => {
    setCv((prev) => ({ ...prev, design: { ...prev.design, ...patch } }))
  }, [])

  const value = useMemo(
    () => ({ cv, updatePersonal, updateItem, addItem, removeItem, moveItem, updateDesign, replaceCv: setCv }),
    [cv, updatePersonal, updateItem, addItem, removeItem, moveItem, updateDesign],
  )

  return <CvContext.Provider value={value}>{children}</CvContext.Provider>
}

export function useCv() {
  const context = useContext(CvContext)
  if (!context) throw new Error('useCv must be used within CvProvider')
  return context
}
