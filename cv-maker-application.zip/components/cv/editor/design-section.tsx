'use client'

import { Check, LayoutTemplate, Palette, Type } from 'lucide-react'
import { useCv } from '@/components/cv/cv-provider'
import { ACCENTS, type FontStyle, TEMPLATES, type TemplateId } from '@/lib/cv-types'
import { cn } from '@/lib/utils'
import { SectionCard } from './form-parts'

function TemplateThumb({ id, accent }: { id: TemplateId; accent: string }) {
  const line = 'h-1 rounded-full bg-foreground/15'
  if (id === 'modern') {
    return (
      <div className="flex h-full">
        <div className="flex w-1/3 flex-col gap-1 p-1.5" style={{ backgroundColor: accent }}>
          <div className="h-1.5 w-4/5 rounded-full bg-white/80" />
          <div className="h-1 w-3/5 rounded-full bg-white/50" />
          <div className="mt-2 h-1 w-4/5 rounded-full bg-white/40" />
          <div className="h-1 w-3/5 rounded-full bg-white/40" />
        </div>
        <div className="flex flex-1 flex-col gap-1 p-1.5">
          <div className={cn(line, 'w-full')} />
          <div className={cn(line, 'w-4/5')} />
          <div className="mt-1.5 h-1 w-2/5 rounded-full" style={{ backgroundColor: accent }} />
          <div className={cn(line, 'w-full')} />
          <div className={cn(line, 'w-3/4')} />
        </div>
      </div>
    )
  }
  if (id === 'minimal') {
    return (
      <div className="flex h-full flex-col gap-1 p-2">
        <div className="h-2 w-3/5 rounded-full bg-foreground/60" />
        <div className="h-1 w-2/5 rounded-full" style={{ backgroundColor: accent }} />
        {[0, 1, 2].map((row) => (
          <div key={row} className="mt-1 flex gap-1.5">
            <div className={cn(line, 'w-1/4')} />
            <div className="flex flex-1 flex-col gap-1">
              <div className={cn(line, 'w-full')} />
              <div className={cn(line, 'w-3/4')} />
            </div>
          </div>
        ))}
      </div>
    )
  }
  return (
    <div className="flex h-full flex-col items-center gap-1 p-2">
      <div className="h-2 w-3/5 rounded-full bg-foreground/60" />
      <div className="h-1 w-2/5 rounded-full" style={{ backgroundColor: accent }} />
      <div className="mt-1 h-px w-full bg-foreground/20" />
      {[0, 1].map((row) => (
        <div key={row} className="mt-1 flex w-full flex-col gap-1">
          <div className="h-1 w-1/3 rounded-full" style={{ backgroundColor: accent }} />
          <div className={cn(line, 'w-full')} />
          <div className={cn(line, 'w-4/5')} />
        </div>
      ))}
    </div>
  )
}

const FONTS: { id: FontStyle; label: string; sample: string; className: string }[] = [
  { id: 'serif', label: 'Serif', sample: 'Aa', className: 'font-serif' },
  { id: 'sans', label: 'Sans', sample: 'Aa', className: 'font-sans' },
]

export function DesignSection() {
  const { cv, updateDesign } = useCv()
  const { template, accent, font } = cv.design

  return (
    <div className="grid gap-4">
      <SectionCard title="Template" description="Pick a layout. Your content stays the same." icon={LayoutTemplate}>
        <div role="radiogroup" aria-label="Template" className="grid grid-cols-3 gap-3">
          {TEMPLATES.map((t) => {
            const selected = t.id === template
            return (
              <button
                key={t.id}
                type="button"
                role="radio"
                aria-checked={selected}
                onClick={() => updateDesign({ template: t.id })}
                className={cn(
                  'group flex flex-col gap-2 rounded-lg p-1.5 text-left transition-colors focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none',
                  selected ? 'bg-primary/10' : 'hover:bg-muted',
                )}
              >
                <div
                  className={cn(
                    'aspect-[210/297] overflow-hidden rounded-md border bg-white shadow-sm transition-shadow',
                    selected ? 'ring-2 ring-primary' : 'group-hover:shadow',
                  )}
                >
                  <TemplateThumb id={t.id} accent={accent} />
                </div>
                <span className="px-0.5">
                  <span className="block text-sm font-medium">{t.name}</span>
                  <span className="block text-xs text-muted-foreground">{t.description}</span>
                </span>
              </button>
            )
          })}
        </div>
      </SectionCard>

      <SectionCard title="Accent colour" description="Used for headings and highlights." icon={Palette}>
        <div role="radiogroup" aria-label="Accent colour" className="flex flex-wrap gap-3">
          {ACCENTS.map((a) => {
            const selected = a.value === accent
            return (
              <button
                key={a.value}
                type="button"
                role="radio"
                aria-checked={selected}
                aria-label={a.name}
                title={a.name}
                onClick={() => updateDesign({ accent: a.value })}
                className={cn(
                  'flex size-9 items-center justify-center rounded-full ring-offset-2 ring-offset-card transition focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none',
                  selected && 'ring-2 ring-foreground/70',
                )}
                style={{ backgroundColor: a.value }}
              >
                {selected ? <Check className="size-4 text-white" aria-hidden="true" /> : null}
              </button>
            )
          })}
        </div>
      </SectionCard>

      <SectionCard title="Typography" description="The typeface used across your CV." icon={Type}>
        <div role="radiogroup" aria-label="Typeface" className="grid grid-cols-2 gap-3">
          {FONTS.map((f) => {
            const selected = f.id === font
            return (
              <button
                key={f.id}
                type="button"
                role="radio"
                aria-checked={selected}
                onClick={() => updateDesign({ font: f.id })}
                className={cn(
                  'flex items-center gap-3 rounded-lg border p-3 text-left transition-colors focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none',
                  selected ? 'border-primary bg-primary/5' : 'hover:bg-muted',
                )}
              >
                <span className={cn('text-2xl', f.className)} aria-hidden="true">
                  {f.sample}
                </span>
                <span className="text-sm font-medium">{f.label}</span>
              </button>
            )
          })}
        </div>
      </SectionCard>
    </div>
  )
}
