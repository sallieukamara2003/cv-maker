'use client'

import { useId } from 'react'
import { BriefcaseBusiness, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCv } from '@/components/cv/cv-provider'
import { EmptyHint, Field, ItemCard, SectionCard } from './form-parts'

function CurrentToggle({ checked, onChange }: { checked: boolean; onChange: (value: boolean) => void }) {
  const id = useId()
  return (
    <label htmlFor={id} className="flex items-center gap-2 text-sm text-muted-foreground sm:col-span-2">
      <input
        id={id}
        type="checkbox"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
        className="size-4 rounded accent-primary"
      />
      I currently work here
    </label>
  )
}

export function ExperienceSection() {
  const { cv, addItem, updateItem, removeItem, moveItem } = useCv()

  return (
    <SectionCard
      title="Experience"
      description="Most recent first. One achievement per line."
      icon={BriefcaseBusiness}
      action={
        <Button type="button" variant="outline" size="sm" onClick={() => addItem('experience')}>
          <Plus data-icon="inline-start" />
          Add
        </Button>
      }
    >
      <div className="grid gap-3">
        {cv.experience.length === 0 ? <EmptyHint>No roles yet. Add your first position.</EmptyHint> : null}
        {cv.experience.map((job, index) => (
          <ItemCard
            key={job.id}
            heading={job.role || job.company || 'Untitled role'}
            index={index}
            total={cv.experience.length}
            onMove={(dir) => moveItem('experience', job.id, dir)}
            onRemove={() => removeItem('experience', job.id)}
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <Field
                label="Job title"
                value={job.role}
                onChange={(v) => updateItem('experience', job.id, { role: v })}
                placeholder="Product Manager"
              />
              <Field
                label="Company"
                value={job.company}
                onChange={(v) => updateItem('experience', job.id, { company: v })}
                placeholder="Acme Inc."
              />
              <Field
                label="Start"
                value={job.start}
                onChange={(v) => updateItem('experience', job.id, { start: v })}
                placeholder="Jan 2022"
              />
              {job.current ? (
                <Field label="End" value="Present" onChange={() => {}} className="pointer-events-none opacity-60" />
              ) : (
                <Field
                  label="End"
                  value={job.end}
                  onChange={(v) => updateItem('experience', job.id, { end: v })}
                  placeholder="Dec 2024"
                />
              )}
              <CurrentToggle
                checked={job.current}
                onChange={(v) => updateItem('experience', job.id, { current: v })}
              />
              <Field
                label="Location"
                value={job.location}
                onChange={(v) => updateItem('experience', job.id, { location: v })}
                placeholder="Remote"
                className="sm:col-span-2"
              />
              <Field
                label="Highlights"
                multiline
                rows={4}
                value={job.description}
                onChange={(v) => updateItem('experience', job.id, { description: v })}
                placeholder={'Shipped X, improving Y by Z%\nLed a team of N people'}
                hint="Each line becomes a bullet point."
                className="sm:col-span-2"
              />
            </div>
          </ItemCard>
        ))}
      </div>
    </SectionCard>
  )
}
