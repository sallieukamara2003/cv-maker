'use client'

import { GraduationCap, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCv } from '@/components/cv/cv-provider'
import { EmptyHint, Field, ItemCard, SectionCard } from './form-parts'

export function EducationSection() {
  const { cv, addItem, updateItem, removeItem, moveItem } = useCv()

  return (
    <SectionCard
      title="Education"
      description="Degrees, diplomas and certifications."
      icon={GraduationCap}
      action={
        <Button type="button" variant="outline" size="sm" onClick={() => addItem('education')}>
          <Plus data-icon="inline-start" />
          Add
        </Button>
      }
    >
      <div className="grid gap-3">
        {cv.education.length === 0 ? <EmptyHint>No education added yet.</EmptyHint> : null}
        {cv.education.map((edu, index) => (
          <ItemCard
            key={edu.id}
            heading={edu.degree || edu.school || 'Untitled entry'}
            index={index}
            total={cv.education.length}
            onMove={(dir) => moveItem('education', edu.id, dir)}
            onRemove={() => removeItem('education', edu.id)}
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <Field
                label="Degree"
                value={edu.degree}
                onChange={(v) => updateItem('education', edu.id, { degree: v })}
                placeholder="BSc Computer Science"
                className="sm:col-span-2"
              />
              <Field
                label="School"
                value={edu.school}
                onChange={(v) => updateItem('education', edu.id, { school: v })}
                placeholder="University name"
              />
              <Field
                label="Location"
                value={edu.location}
                onChange={(v) => updateItem('education', edu.id, { location: v })}
                placeholder="City"
              />
              <Field
                label="Start"
                value={edu.start}
                onChange={(v) => updateItem('education', edu.id, { start: v })}
                placeholder="2016"
              />
              <Field
                label="End"
                value={edu.end}
                onChange={(v) => updateItem('education', edu.id, { end: v })}
                placeholder="2020"
              />
              <Field
                label="Details"
                multiline
                rows={2}
                value={edu.details}
                onChange={(v) => updateItem('education', edu.id, { details: v })}
                placeholder="Honours, thesis, relevant coursework"
                className="sm:col-span-2"
              />
            </div>
          </ItemCard>
        ))}
      </div>
    </SectionCard>
  )
}
