'use client'

import { UserRound } from 'lucide-react'
import { useCv } from '@/components/cv/cv-provider'
import { Field, SectionCard } from './form-parts'

export function PersonalSection() {
  const { cv, updatePersonal } = useCv()
  const p = cv.personal

  return (
    <SectionCard title="Personal details" description="How employers will reach you." icon={UserRound}>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field
          label="Full name"
          value={p.fullName}
          onChange={(v) => updatePersonal('fullName', v)}
          placeholder="Jane Doe"
          autoComplete="name"
        />
        <Field
          label="Job title"
          value={p.title}
          onChange={(v) => updatePersonal('title', v)}
          placeholder="Software Engineer"
          autoComplete="organization-title"
        />
        <Field
          label="Email"
          type="email"
          value={p.email}
          onChange={(v) => updatePersonal('email', v)}
          placeholder="jane@email.com"
          autoComplete="email"
        />
        <Field
          label="Phone"
          type="tel"
          value={p.phone}
          onChange={(v) => updatePersonal('phone', v)}
          placeholder="+1 555 0100"
          autoComplete="tel"
        />
        <Field
          label="Location"
          value={p.location}
          onChange={(v) => updatePersonal('location', v)}
          placeholder="City, Country"
        />
        <Field
          label="Website"
          value={p.website}
          onChange={(v) => updatePersonal('website', v)}
          placeholder="janedoe.com"
          autoComplete="url"
        />
        <Field
          label="LinkedIn"
          value={p.linkedin}
          onChange={(v) => updatePersonal('linkedin', v)}
          placeholder="linkedin.com/in/janedoe"
          className="sm:col-span-2"
        />
        <Field
          label="Professional summary"
          multiline
          rows={5}
          value={p.summary}
          onChange={(v) => updatePersonal('summary', v)}
          placeholder="Two or three sentences about your experience and what you bring."
          className="sm:col-span-2"
        />
      </div>
    </SectionCard>
  )
}
