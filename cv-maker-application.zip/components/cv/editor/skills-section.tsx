'use client'

import { useId, useState } from 'react'
import { Languages, Plus, Sparkles, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useCv } from '@/components/cv/cv-provider'
import { EmptyHint, Field, ItemCard, SectionCard } from './form-parts'

export function SkillsSection() {
  const { cv, addItem, removeItem } = useCv()
  const [draft, setDraft] = useState('')
  const inputId = useId()

  function commit() {
    const names = draft
      .split(',')
      .map((name) => name.trim())
      .filter(Boolean)
    names.forEach((name) => addItem('skills', { name }))
    setDraft('')
  }

  return (
    <SectionCard title="Skills" description="Press Enter or use commas to add several." icon={Sparkles}>
      <form
        className="flex gap-2"
        onSubmit={(event) => {
          event.preventDefault()
          commit()
        }}
      >
        <Label htmlFor={inputId} className="sr-only">
          New skill
        </Label>
        <Input
          id={inputId}
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === 'Enter' && (event.nativeEvent.isComposing || event.keyCode === 229)) {
              event.preventDefault()
            }
          }}
          placeholder="e.g. TypeScript, Public speaking"
          className="bg-background"
        />
        <Button type="submit" variant="outline" disabled={!draft.trim()}>
          <Plus data-icon="inline-start" />
          Add
        </Button>
      </form>

      {cv.skills.length > 0 ? (
        <ul className="mt-4 flex flex-wrap gap-2" aria-label="Your skills">
          {cv.skills.map((skill) => (
            <li
              key={skill.id}
              className="flex items-center gap-1 rounded-full border bg-muted/60 py-1 pr-1 pl-3 text-sm"
            >
              {skill.name}
              <button
                type="button"
                onClick={() => removeItem('skills', skill.id)}
                className="flex size-5 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-foreground/10 hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
                aria-label={`Remove ${skill.name}`}
              >
                <X className="size-3" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </SectionCard>
  )
}

export function LanguagesSection() {
  const { cv, addItem, updateItem, removeItem, moveItem } = useCv()

  return (
    <SectionCard
      title="Languages"
      description="Spoken languages and your proficiency."
      icon={Languages}
      action={
        <Button type="button" variant="outline" size="sm" onClick={() => addItem('languages')}>
          <Plus data-icon="inline-start" />
          Add
        </Button>
      }
    >
      <div className="grid gap-3">
        {cv.languages.length === 0 ? <EmptyHint>No languages added yet.</EmptyHint> : null}
        {cv.languages.map((lang, index) => (
          <ItemCard
            key={lang.id}
            heading={lang.name || 'Untitled language'}
            index={index}
            total={cv.languages.length}
            onMove={(dir) => moveItem('languages', lang.id, dir)}
            onRemove={() => removeItem('languages', lang.id)}
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <Field
                label="Language"
                value={lang.name}
                onChange={(v) => updateItem('languages', lang.id, { name: v })}
                placeholder="Spanish"
              />
              <Field
                label="Level"
                value={lang.level}
                onChange={(v) => updateItem('languages', lang.id, { level: v })}
                placeholder="Fluent"
              />
            </div>
          </ItemCard>
        ))}
      </div>
    </SectionCard>
  )
}
