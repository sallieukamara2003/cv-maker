'use client'

import { useRef, useState } from 'react'
import { Download, FileText, FileUp, RotateCcw, Save } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCv } from '@/components/cv/cv-provider'
import { EMPTY_CV, parseCV } from '@/lib/cv-types'

function slugify(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'my'
}

export function AppHeader() {
  const { cv, replaceCv } = useCv()
  const fileInput = useRef<HTMLInputElement>(null)
  const [status, setStatus] = useState('')

  function handleDownloadPdf() {
    const previousTitle = document.title
    document.title = `${cv.personal.fullName || 'My'} CV`
    window.print()
    document.title = previousTitle
  }

  function handleSaveJson() {
    const blob = new Blob([JSON.stringify(cv, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `${slugify(cv.personal.fullName)}-cv.json`
    link.click()
    URL.revokeObjectURL(url)
    setStatus('CV data saved to your device.')
  }

  async function handleImport(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!file) return
    try {
      const parsed = parseCV(JSON.parse(await file.text()))
      if (!parsed) throw new Error('Invalid file')
      replaceCv(parsed)
      setStatus(`Loaded ${file.name}.`)
    } catch {
      setStatus('That file could not be read. Please choose a CV file saved from this app.')
    }
  }

  function handleClear() {
    if (window.confirm('Start from a blank CV? Unsaved changes will be lost.')) {
      replaceCv({ ...EMPTY_CV, design: cv.design })
      setStatus('Started a blank CV.')
    }
  }

  return (
    <header className="flex h-14 shrink-0 items-center justify-between gap-3 border-b bg-card px-4 print:hidden sm:px-6">
      <div className="flex items-center gap-2.5">
        <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <FileText className="size-4" aria-hidden="true" />
        </span>
        <span className="font-serif text-lg font-semibold tracking-tight">Folio</span>
        <span className="hidden text-sm text-muted-foreground md:inline">CV maker</span>
      </div>

      <p className="sr-only" role="status" aria-live="polite">
        {status}
      </p>

      <div className="flex items-center gap-1.5">
        <Button variant="ghost" size="sm" onClick={handleClear} aria-label="Start a blank CV">
          <RotateCcw data-icon="inline-start" />
          <span className="hidden lg:inline">New</span>
        </Button>
        <Button variant="ghost" size="sm" onClick={() => fileInput.current?.click()} aria-label="Open saved CV file">
          <FileUp data-icon="inline-start" />
          <span className="hidden lg:inline">Open</span>
        </Button>
        <input
          ref={fileInput}
          type="file"
          accept="application/json,.json"
          className="sr-only"
          tabIndex={-1}
          aria-hidden="true"
          onChange={handleImport}
        />
        <Button variant="outline" size="sm" onClick={handleSaveJson} aria-label="Save CV data as a file">
          <Save data-icon="inline-start" />
          <span className="hidden sm:inline">Save</span>
        </Button>
        <Button size="sm" onClick={handleDownloadPdf}>
          <Download data-icon="inline-start" />
          Download PDF
        </Button>
      </div>
    </header>
  )
}
