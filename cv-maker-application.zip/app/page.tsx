import { CvBuilder } from '@/components/cv/cv-builder'

export default function Page() {
  return <CvBuilder />
}
